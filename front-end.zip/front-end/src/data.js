let moviesList = ['Justice League', 'Tenet', 'Fast X', 'Planet of the Apes', 'Come Play'];
let slots = ['10:00 AM', '01:00 PM', '03:00 PM', "08:00 PM"];
let seats = ['A1', 'A2', 'A3', 'A4', 'D1', 'D2'];
exports.moviesList = moviesList;
exports.slots = slots;
exports.seats = seats;